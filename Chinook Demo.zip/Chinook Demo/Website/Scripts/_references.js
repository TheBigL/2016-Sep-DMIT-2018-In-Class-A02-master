﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.min.js" />
/// <reference path="jquery-3.1.1.min.js" />
/// <reference path="jquery-3.1.1.slim.min.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <reference path="respond.matchmedia.addListener.min.js" />
/// <reference path="respond.min.js" />
